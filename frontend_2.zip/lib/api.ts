import type { KpiApiResponse, ClientConfig } from "./types";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

/**
 * Generic fetch wrapper with consistent error handling.
 */
async function apiFetch<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) {
    const detail = await res.text().catch(() => "Unknown error");
    throw new Error(`API ${res.status}: ${detail}`);
  }
  return res.json() as Promise<T>;
}

/**
 * Fetch KPI results for a single client.
 */
export function fetchKpiResults(
  clientName: string,
  start: string,
  end: string,
): Promise<KpiApiResponse> {
  const url = `${API_BASE_URL}/kpi/results/${encodeURIComponent(clientName)}?start=${start}&end=${end}`;
  return apiFetch<KpiApiResponse>(url);
}

/**
 * Fetch KPI results for multiple clients in parallel.
 */
export function fetchAllClientsKpi(
  clients: string[],
  start: string,
  end: string,
): Promise<KpiApiResponse[]> {
  return Promise.all(clients.map((c) => fetchKpiResults(c, start, end)));
}

/**
 * Fetch available clients from the backend.
 * Falls back to a hardcoded list if the endpoint doesn't exist yet —
 * ship the dynamic frontend now, wire up GET /clients later.
 */
export async function fetchClients(): Promise<ClientConfig[]> {
  try {
    return await apiFetch<ClientConfig[]>(`${API_BASE_URL}/clients`);
  } catch {
    return [
      { id: "entfw", name: "ENTFW" },
      { id: "southtexas", name: "South Texas" },
      { id: "prosper", name: "Prosper" },
    ];
  }
}
