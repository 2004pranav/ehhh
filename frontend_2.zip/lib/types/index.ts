// ============================================================
// API Response Types
// Single source of truth for all data shapes from the backend.
// If the backend changes a field, TypeScript will flag every
// consumer that needs updating.
// ============================================================

/** Monthly breakdown entry returned by most KPI endpoints */
export interface MonthlyBreakdown {
  period: string;              // e.g. "Jan 25", "Feb 25"
  [key: string]: string | number; // gcr, denial_rate, total_charges, etc.
}

/** GCR / NCR KPI shape */
export interface RateKpi {
  gcr?: number;
  ncr?: number;
  monthly_breakdown?: MonthlyBreakdown[];
}

/** Total charges / payments / claims KPI shape */
export interface VolumeKpi {
  total_charges?: number;
  total_payments?: number;
  total_claims?: number;
  monthly_breakdown?: MonthlyBreakdown[];
}

/** Denial rate KPI shape */
export interface DenialRateKpi {
  denial_rate: number;
  monthly_breakdown?: MonthlyBreakdown[];
}

/** AR Days KPI shape */
export interface ArDaysKpi {
  average: number;
  months?: MonthlyBreakdown[];
}

/** CCR KPI shape */
export interface CcrKpi {
  average: number;
  months?: MonthlyBreakdown[];
}

/** Single AR aging bucket */
export interface ArAgingBucket {
  period: string;     // e.g. "0-30", "31-60"
  percentage: number;
  amount: number;
}

/** AR aging KPI shape */
export interface ArAgingKpi {
  buckets: ArAgingBucket[];
}

/** Automation KPI for a single process */
export interface AutomationEntry {
  bot: number;
  total: number;
}

/** Raw KPI response from the API (before normalization) */
export interface RawKpis {
  gcr?: RateKpi;
  ncr?: RateKpi;
  total_charges?: VolumeKpi;
  total_payments?: VolumeKpi;
  total_claims?: VolumeKpi;
  daily_charge_avg?: number;
  daily_payment_avg?: number;
  ar_aging?: ArAgingKpi;
  automation?: Record<string, AutomationEntry>;
  denial_rate?: DenialRateKpi;
  ar_days?: ArDaysKpi;
  ccr?: CcrKpi;
  prev_gcr?: RateKpi;
  prev_denial_rate?: DenialRateKpi;
  prev_period_ccr?: CcrKpi;
}

/** Full API response wrapper */
export interface KpiApiResponse {
  client: string;
  period_start: string;
  period_end: string;
  kpis: RawKpis;
}

// ============================================================
// Normalized KPIs — the shape every component consumes
// This is what dashboard-context.tsx provides via useDashboard()
// ============================================================

export interface NormalizedKpis {
  // Scalar values for KPI cards
  gcr: number;
  ncr: number;
  total_charges: number;
  total_payments: number;
  total_claims: number;
  daily_charge_avg: number;
  daily_payment_avg: number;
  denial_rate: number;
  ar_days: number;
  ccr: number;

  // Full objects for charts (contain monthly breakdowns)
  gcr_full: RateKpi | null;
  ncr_full: RateKpi | null;
  total_charges_full: VolumeKpi | null;
  total_payments_full: VolumeKpi | null;
  total_claims_full: VolumeKpi | null;
  denial_rate_full: DenialRateKpi | null;
  ar_days_full: ArDaysKpi | null;
  ccr_full: CcrKpi | null;

  // AR aging
  ar_aging: ArAgingKpi | null;

  // Automation
  automation: Record<string, AutomationEntry> | null;

  // Previous period comparisons
  prev_gcr: number;
  prev_denial_rate: number;
  prev_period_ccr: number;
}

// ============================================================
// Client configuration
// ============================================================

export interface ClientConfig {
  id: string;
  name: string;
}

// ============================================================
// Dashboard state
// ============================================================

export interface DateRange {
  from: string; // YYYY-MM-DD
  to: string;   // YYYY-MM-DD
}
