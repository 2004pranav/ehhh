import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from "react";
import type { NormalizedKpis, ClientConfig, DateRange } from "./types";
import { fetchDashboardKpis } from "./kpi-helpers";
import { fetchClients } from "./api";

// ============================================================
// Context shape
// ============================================================

interface DashboardContextValue {
  // Client management
  clients: ClientConfig[];
  clientsLoading: boolean;
  activeClientIds: string[];
  setActiveClientIds: (ids: string[]) => void;

  // Date range
  dateRange: DateRange;
  setDateRange: (range: DateRange) => void;

  // KPI data
  kpis: NormalizedKpis | null;
  kpisLoading: boolean;
  kpisError: string | null;
  retryKpis: () => void;
}

const DashboardContext = createContext<DashboardContextValue | undefined>(undefined);

// ============================================================
// Provider
// ============================================================

export function DashboardProvider({ children }: { children: ReactNode }) {
  // --- Client list (fetched once on mount) ---
  const [clients, setClients] = useState<ClientConfig[]>([]);
  const [clientsLoading, setClientsLoading] = useState(true);

  useEffect(() => {
    fetchClients()
      .then(setClients)
      .catch((e) => console.error("Failed to load clients:", e))
      .finally(() => setClientsLoading(false));
  }, []);

  // --- Active selection (defaults to first client once loaded) ---
  const [activeClientIds, setActiveClientIds] = useState<string[]>([]);

  // Set default selection once clients load
  useEffect(() => {
    if (clients.length > 0 && activeClientIds.length === 0) {
      setActiveClientIds([clients[0].id]);
    }
  }, [clients, activeClientIds.length]);

  // --- Date range ---
  const [dateRange, setDateRange] = useState<DateRange>({
    from: "2025-01-01",
    to: "2025-03-31",
  });

  // --- KPI data ---
  const [kpis, setKpis] = useState<NormalizedKpis | null>(null);
  const [kpisLoading, setKpisLoading] = useState(false);
  const [kpisError, setKpisError] = useState<string | null>(null);

  const loadKpis = useCallback(async () => {
    if (activeClientIds.length === 0) return;

    setKpisLoading(true);
    setKpisError(null);
    setKpis(null);

    try {
      const data = await fetchDashboardKpis(
        activeClientIds,
        dateRange.from,
        dateRange.to,
      );
      setKpis(data);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to load KPI data";
      console.error("KPI fetch failed:", msg);
      setKpisError(msg);
    } finally {
      setKpisLoading(false);
    }
  }, [activeClientIds, dateRange]);

  // Fetch whenever client or date changes
  useEffect(() => {
    loadKpis();
  }, [loadKpis]);

  return (
    <DashboardContext.Provider
      value={{
        clients,
        clientsLoading,
        activeClientIds,
        setActiveClientIds,
        dateRange,
        setDateRange,
        kpis,
        kpisLoading,
        kpisError,
        retryKpis: loadKpis,
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
}

// ============================================================
// Hook
// ============================================================

export function useDashboard() {
  const context = useContext(DashboardContext);
  if (!context) {
    throw new Error("useDashboard must be used within DashboardProvider");
  }
  return context;
}

// ============================================================
// Date format helpers
// ============================================================

/** YYYY-MM-DD → MM-DD-YYYY for display */
export function toDisplayDate(isoDate: string): string {
  const [y, m, d] = isoDate.split("-");
  return `${m}-${d}-${y}`;
}

/** MM-DD-YYYY → YYYY-MM-DD for API */
export function toApiDate(displayDate: string): string {
  const [m, d, y] = displayDate.split("-");
  return `${y}-${m}-${d}`;
}
