import type { RawKpis, NormalizedKpis } from "./types";
import { fetchKpiResults, fetchAllClientsKpi } from "./api";

/**
 * Normalize raw API kpis into a flat, typed object that every
 * component can consume without null-checking nested shapes.
 */
function normalizeKpis(kpis: RawKpis): NormalizedKpis {
  return {
    // Scalar values for KPI cards
    gcr: kpis.gcr?.gcr ?? 0,
    ncr: kpis.ncr?.ncr ?? 0,
    total_charges: kpis.total_charges?.total_charges ?? 0,
    total_payments: kpis.total_payments?.total_payments ?? 0,
    total_claims: kpis.total_claims?.total_claims ?? 0,
    daily_charge_avg: kpis.daily_charge_avg ?? 0,
    daily_payment_avg: kpis.daily_payment_avg ?? 0,
    denial_rate: kpis.denial_rate?.denial_rate ?? 0,
    ar_days: kpis.ar_days?.average ?? 0,
    ccr: kpis.ccr?.average ?? 0,

    // Full objects for charts
    gcr_full: kpis.gcr ?? null,
    ncr_full: kpis.ncr ?? null,
    total_charges_full: kpis.total_charges ?? null,
    total_payments_full: kpis.total_payments ?? null,
    total_claims_full: kpis.total_claims ?? null,
    denial_rate_full: kpis.denial_rate ?? null,
    ar_days_full: kpis.ar_days ?? null,
    ccr_full: kpis.ccr ?? null,

    // Nested data
    ar_aging: kpis.ar_aging ?? null,
    automation: kpis.automation ?? null,

    // Previous period
    prev_gcr: kpis.prev_gcr?.gcr ?? 0,
    prev_denial_rate: kpis.prev_denial_rate?.denial_rate ?? 0,
    prev_period_ccr: kpis.prev_period_ccr?.average ?? 0,
  };
}

/**
 * Fetch and normalize KPI data for a given set of client IDs.
 */
export async function fetchDashboardKpis(
  clientIds: string[],
  start: string,
  end: string,
): Promise<NormalizedKpis> {
  if (clientIds.length === 1) {
    const res = await fetchKpiResults(clientIds[0], start, end);
    return normalizeKpis(res.kpis);
  }

  const responses = await fetchAllClientsKpi(clientIds, start, end);
  const merged = mergeKpis(responses.map((r) => r.kpis));
  return normalizeKpis(merged);
}

/**
 * Merge KPI objects from multiple clients.
 * Sums absolute values, averages rates/percentages.
 */
function mergeKpis(kpiList: RawKpis[]): RawKpis {
  if (kpiList.length === 0) return {};
  if (kpiList.length === 1) return kpiList[0];

  const merged: Record<string, unknown> = {};
  const allKeys = new Set(kpiList.flatMap((k) => Object.keys(k)));

  const avgKeys = new Set([
    "gcr", "denial_rate", "ccr", "ar_days",
    "GCR", "Denial Rate", "CCR", "AR Days",
    "denial_rate_percentage", "clean_claim_rate",
  ]);

  for (const key of allKeys) {
    const values = kpiList
      .map((k) => (k as Record<string, unknown>)[key])
      .filter((v) => v !== undefined);
    if (values.length === 0) continue;

    if (typeof values[0] === "number") {
      const sum = (values as number[]).reduce((a, b) => a + b, 0);
      merged[key] = avgKeys.has(key) ? sum / values.length : sum;
    } else if (Array.isArray(values[0])) {
      merged[key] = values.flat();
    } else {
      merged[key] = values[0];
    }
  }

  return merged as RawKpis;
}
