'use client'

import { DashboardProvider, useDashboard } from '@/lib/dashboard-context'
import { DashboardSidebar } from '@/components/dashboard/sidebar'
import { DashboardHeader } from '@/components/dashboard/header'
import { KpiCards } from '@/components/dashboard/kpi-cards'
import { AutomationKpis } from '@/components/dashboard/automation-kpis'
import {
  PerformanceTrendsChart,
  RevenueChart,
  ArAgingChart,
  ARDaysTrendChart,
  PeriodComparisonChart,
} from '@/components/dashboard/charts'
import { AlertCircle, RefreshCw } from 'lucide-react'

function ErrorBanner() {
  const { kpisError, retryKpis } = useDashboard()

  if (!kpisError) return null

  return (
    <div className="mx-4 mt-4 flex items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3">
      <AlertCircle className="h-4 w-4 shrink-0 text-destructive" />
      <p className="flex-1 text-sm text-destructive">{kpisError}</p>
      <button
        onClick={retryKpis}
        className="flex items-center gap-1.5 rounded-md bg-destructive/10 px-3 py-1.5 text-xs font-medium text-destructive transition-colors hover:bg-destructive/20"
      >
        <RefreshCw className="h-3 w-3" />
        Retry
      </button>
    </div>
  )
}

function DashboardContent() {
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        <ErrorBanner />

        <main className="flex-1 overflow-hidden p-4">
          {/* Outer 70/30 split — automation panel spans full height on the right */}
          <div className="flex gap-4 h-full">

            {/* LEFT 70% — KPI cards + 2 chart rows */}
            <div className="flex-[7] flex flex-col gap-4 min-h-0">

              {/* KPI Cards */}
              <div className="shrink-0">
                <KpiCards />
              </div>

              {/* Row 1: AR Aging | AR Days Trend | Period Comparison */}
              <div className="flex-1 grid grid-cols-3 gap-4 min-h-0">
                <ArAgingChart />
                <ARDaysTrendChart />
                <PeriodComparisonChart />
              </div>

              {/* Row 2: Performance Trends | Revenue Overview */}
              <div className="flex-1 grid grid-cols-2 gap-4 min-h-0">
                <PerformanceTrendsChart />
                <RevenueChart />
              </div>

            </div>

            {/* RIGHT 30% — Automation panel, full height */}
            <div className="flex-[3] min-h-0 overflow-y-auto">
              <AutomationKpis />
            </div>

          </div>
        </main>
      </div>
    </div>
  )
}

export default function Page() {
  return (
    <DashboardProvider>
      <DashboardContent />
    </DashboardProvider>
  )
}
