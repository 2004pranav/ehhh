import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import { BLUE, PURPLE } from "./chart-constants";

interface ComparisonData {
  gcr: number;
  ccr: number;
  dr: number;
}

export function PeriodComparisonChart() {
  const { kpis, kpisLoading } = useDashboard();

  const { currentData, previousData } = useMemo<{
    currentData: ComparisonData;
    previousData: ComparisonData;
  }>(() => {
    const empty = { gcr: 0, ccr: 0, dr: 0 };
    if (!kpis) return { currentData: empty, previousData: empty };
    try {
      return {
        currentData: {
          gcr: Number(kpis.gcr) || 0,
          ccr: Number(kpis.ccr) || 0,
          dr: (Number(kpis.denial_rate) || 0) * 100,
        },
        previousData: {
          gcr: Number(kpis.prev_gcr) || 0,
          ccr: Number(kpis.prev_period_ccr) || 0,
          dr: Number(kpis.prev_denial_rate) || 0,
        },
      };
    } catch (error) {
      console.error("Error processing period comparison:", error);
      return { currentData: empty, previousData: empty };
    }
  }, [kpis]);

  if (kpisLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Period Comparison</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    );
  }

  const metrics = [
    { label: "GCR", current: currentData.gcr, previous: previousData.gcr },
    { label: "CCR", current: currentData.ccr, previous: previousData.ccr },
    { label: "DR", current: currentData.dr, previous: previousData.dr },
  ];

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-9">
        <div className="flex flex-col gap-5">
          <CardTitle className="text-base font-semibold text-card-foreground">
            Period Comparison
          </CardTitle>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>
              PREV:{" "}
              <span className="font-semibold" style={{ color: PURPLE }}>
                PREVIOUS PERIOD
              </span>
            </span>
            <span>
              CURR:{" "}
              <span className="font-semibold" style={{ color: BLUE }}>
                JAN 25 - DEC 25
              </span>
            </span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="flex flex-col justify-between h-[220px]">
          <div className="flex flex-col gap-5">
            {metrics.map((metric) => {
              const metricMax = metric.label === "DR" ? 10 : 100;
              const prevW = (metric.previous / metricMax) * 100;
              const currW = (metric.current / metricMax) * 100;

              return (
                <div key={metric.label} className="flex items-center gap-4">
                  <span className="w-9 text-sm font-semibold text-muted-foreground shrink-0">
                    {metric.label}
                  </span>

                  <div className="flex-1 flex flex-col gap-2">
                    {/* Previous */}
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-3 rounded-full bg-secondary overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{ width: `${prevW}%`, backgroundColor: PURPLE, opacity: 0.85 }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground w-10 text-right shrink-0">
                        {metric.previous.toFixed(1)}%
                      </span>
                    </div>

                    {/* Current */}
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-3 rounded-full bg-secondary overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{ width: `${currW}%`, backgroundColor: BLUE }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground w-10 text-right shrink-0">
                        {metric.current.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex justify-center gap-6 pt-4">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: PURPLE }} />
              <span className="text-xs text-muted-foreground">Previous</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: BLUE }} />
              <span className="text-xs text-muted-foreground">Current</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
