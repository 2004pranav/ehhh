import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LineChart, Line, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { useState, useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import type { MonthlyBreakdown } from "@/lib/types";
import { BLUE } from "./chart-constants";

interface TrendPoint {
  month: string;
  GCR?: number;
  DR?: number;
  CCR?: number;
}

export function PerformanceTrendsChart() {
  const [metric, setMetric] = useState<"GCR" | "DR" | "CCR">("GCR");
  const { kpis, kpisLoading } = useDashboard();

  const data = useMemo<TrendPoint[]>(() => {
    if (!kpis) return [];
    try {
      const gcrData = kpis.gcr_full?.monthly_breakdown ?? [];
      const drData = kpis.denial_rate_full?.monthly_breakdown ?? [];
      const ccrData = kpis.ccr_full?.months ?? [];

      const map = new Map<string, TrendPoint>();

      gcrData.forEach((item: MonthlyBreakdown) => {
        const p = item.period;
        if (!map.has(p)) map.set(p, { month: p });
        map.get(p)!.GCR = Number(item.gcr) || 0;
      });

      drData.forEach((item: MonthlyBreakdown) => {
        const p = item.period;
        if (!map.has(p)) map.set(p, { month: p });
        map.get(p)!.DR = (Number(item.denial_rate) || 0) * 100;
      });

      ccrData.forEach((item: MonthlyBreakdown) => {
        const p = item.period;
        if (!map.has(p)) map.set(p, { month: p });
        map.get(p)!.CCR = Number(item.ccr) || 0;
      });

      return Array.from(map.values()).sort(
        (a, b) => new Date(`1 ${a.month}`).getTime() - new Date(`1 ${b.month}`).getTime(),
      );
    } catch (error) {
      console.error("Error processing performance data:", error);
      return [];
    }
  }, [kpis]);

  if (kpisLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Performance Trends</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">Performance Trends</CardTitle>
        <Tabs value={metric} onValueChange={(v) => setMetric(v as typeof metric)}>
          <TabsList className="h-7 gap-0 p-0.5">
            {(["GCR", "DR", "CCR"] as const).map((m) => (
              <TabsTrigger key={m} value={m} className="h-6 px-2.5 text-xs">{m}</TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="130%">
            <LineChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="blueShade" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={BLUE} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={BLUE} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="hsl(220, 13%, 91%)" strokeDasharray="3 3" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} tickFormatter={(v) => `${v}%`} />
              <Tooltip
                contentStyle={{ borderRadius: "8px", border: "1px solid hsl(220, 13%, 91%)", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)", fontSize: "12px" }}
                formatter={(value: number) => [`${value.toFixed(1)}%`, metric]}
              />
              <Area type="monotone" dataKey={metric} stroke="none" fill="url(#blueShade)" />
              <Line type="monotone" dataKey={metric} stroke={BLUE} strokeWidth={2.5} dot={{ r: 3, fill: "white", stroke: BLUE, strokeWidth: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
