import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import type { MonthlyBreakdown } from "@/lib/types";
import { BLUE, PURPLE } from "./chart-constants";

interface RevenuePoint {
  month: string;
  Charges: number;
  Payments: number;
}

export function RevenueChart() {
  const { kpis, kpisLoading } = useDashboard();

  const data = useMemo<RevenuePoint[]>(() => {
    if (!kpis) return [];
    try {
      const charges = kpis.total_charges_full?.monthly_breakdown ?? [];
      const payments = kpis.total_payments_full?.monthly_breakdown ?? [];

      const map = new Map<string, RevenuePoint>();

      charges.forEach((item: MonthlyBreakdown) => {
        map.set(item.period, {
          month: item.period,
          Charges: Number(item.total_charges) || 0,
          Payments: 0,
        });
      });

      payments.forEach((item: MonthlyBreakdown) => {
        if (map.has(item.period)) {
          map.get(item.period)!.Payments = Number(item.total_payments) || 0;
        } else {
          map.set(item.period, {
            month: item.period,
            Charges: 0,
            Payments: Number(item.total_payments) || 0,
          });
        }
      });

      return Array.from(map.values()).sort(
        (a, b) => new Date(`01 ${a.month}`).getTime() - new Date(`01 ${b.month}`).getTime(),
      );
    } catch (error) {
      console.error("Error processing revenue data:", error);
      return [];
    }
  }, [kpis]);

  if (kpisLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Revenue Overview</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">Revenue Overview</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="130%">
            <AreaChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="gradPayments" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={BLUE} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={BLUE} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradCharges" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={PURPLE} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={PURPLE} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="hsl(220, 13%, 91%)" strokeDasharray="3 3" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} tickFormatter={(v) => `$${(v / 1000000).toFixed(0)}M`} />
              <Tooltip
                contentStyle={{ borderRadius: "8px", border: "1px solid hsl(220, 13%, 91%)", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)", fontSize: "12px" }}
                formatter={(value: number) => [`$${(value / 1000000).toFixed(2)}M`]}
              />
              <Area type="monotone" dataKey="Charges" stroke={PURPLE} strokeWidth={2} fill="url(#gradCharges)" dot={{ r: 2 }} />
              <Area type="monotone" dataKey="Payments" stroke={BLUE} strokeWidth={2} fill="url(#gradPayments)" dot={{ r: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-5 pt-19">
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: BLUE }} />
            Payments
          </div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: PURPLE }} />
            Billed
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
