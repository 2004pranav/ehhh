export const BLUE = "hsl(217, 91%, 60%)";
export const PURPLE = "hsl(262, 83%, 58%)";
export const AMBER = "hsl(38, 92%, 50%)";
export const RED = "hsl(0, 84%, 60%)";
export const PIE_COLORS = [BLUE, PURPLE, AMBER, RED];

export const formatAmount = (value: number) => {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`;
  return `$${(value / 1_000).toFixed(0)}K`;
};

const monthMap: Record<string, number> = {
  Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
  Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11,
};

export const parseMonth = (str: string) => {
  const [mon, yr] = str.split(" ");
  const date = new Date(Number(`20${yr}`), monthMap[mon], 1);
  date.setHours(0, 0, 0, 0);
  return date;
};
