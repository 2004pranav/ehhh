import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { useState, useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import type { MonthlyBreakdown } from "@/lib/types";
import { PURPLE, parseMonth } from "./chart-constants";

interface TrendPoint {
  month: string;
  claims: number;
  arDays: number;
}

export function ARDaysTrendChart() {
  const { dateRange, kpis, kpisLoading } = useDashboard();
  const [activeTab, setActiveTab] = useState<"arDays" | "claims">("arDays");

  const data = useMemo<TrendPoint[]>(() => {
    if (!kpis) return [];
    try {
      const claimsData = kpis.total_claims_full?.monthly_breakdown ?? [];
      const arDaysData = kpis.ar_days_full?.months ?? [];

      const dataMap = new Map<string, TrendPoint>();

      claimsData.forEach((item: MonthlyBreakdown) => {
        dataMap.set(item.period, {
          month: item.period,
          claims: Number(item.total_claims) || 0,
          arDays: 0,
        });
      });

      arDaysData.forEach((item: MonthlyBreakdown) => {
        if (!dataMap.has(item.period)) {
          dataMap.set(item.period, { month: item.period, claims: 0, arDays: 0 });
        }
        dataMap.get(item.period)!.arDays = Number(item.ar_days) || 0;
      });

      const start = new Date(dateRange.from);
      start.setHours(0, 0, 0, 0);
      const end = new Date(dateRange.to);
      end.setHours(23, 59, 59, 999);

      return Array.from(dataMap.values())
        .filter((item) => {
          const d = parseMonth(item.month);
          return d >= start && d <= end;
        })
        .sort((a, b) => parseMonth(a.month).getTime() - parseMonth(b.month).getTime());
    } catch (error) {
      console.error("Error processing AR days trend:", error);
      return [];
    }
  }, [kpis, dateRange]);

  if (kpisLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Loading Trend...</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    );
  }

  const dataKey = activeTab === "arDays" ? "arDays" : "claims";

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-10">
        <CardTitle className="text-base font-semibold text-card-foreground">
          {activeTab === "arDays" ? "AR Days Trend" : "Claims Trend"}
        </CardTitle>
        <div className="flex items-center rounded-lg border border-border overflow-hidden">
          <button
            onClick={() => setActiveTab("claims")}
            className={`px-3 py-1 text-xs font-medium transition-colors ${activeTab === "claims" ? "bg-card-foreground text-card" : "bg-card text-muted-foreground hover:bg-secondary"}`}
          >
            Claims
          </button>
          <button
            onClick={() => setActiveTab("arDays")}
            className={`px-3 py-1 text-xs font-medium transition-colors ${activeTab === "arDays" ? "bg-card-foreground text-card" : "bg-card text-muted-foreground hover:bg-secondary"}`}
          >
            AR Days
          </button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="110%">
            <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="hsl(220, 13%, 91%)" strokeDasharray="3 3" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }}
                tickFormatter={(v: number) => (activeTab === "arDays" ? `${v.toFixed(0)}d` : v.toLocaleString())}
              />
              <Tooltip
                contentStyle={{ borderRadius: "8px", border: "1px solid hsl(220, 13%, 91%)", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)", fontSize: "12px" }}
                formatter={(value: number) => [activeTab === "arDays" ? `${value.toFixed(1)}d` : value.toLocaleString(), activeTab === "arDays" ? "AR Days" : "Claims"]}
              />
              <Bar dataKey={dataKey} fill={PURPLE} barSize={16} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-2 pt-8">
          <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: PURPLE }} />
          <span className="text-xs font-medium text-muted-foreground">
            {activeTab === "arDays" ? "Average Days" : "Claims"}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
