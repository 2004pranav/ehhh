import { useState } from "react";
import { useDashboard, toDisplayDate, toApiDate } from "@/lib/dashboard-context";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "lucide-react";

/** Validates MM-DD-YYYY format and checks it's a real date */
function isValidDisplayDate(str: string): boolean {
  if (!/^\d{2}-\d{2}-\d{4}$/.test(str)) return false;
  const [m, d, y] = str.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return (
    date.getFullYear() === y &&
    date.getMonth() === m - 1 &&
    date.getDate() === d
  );
}

export function DashboardHeader() {
  const { dateRange, setDateRange } = useDashboard();
  const [fromDisplay, setFromDisplay] = useState(toDisplayDate(dateRange.from));
  const [toDisplay, setToDisplay] = useState(toDisplayDate(dateRange.to));
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleApply = () => {
    setError(null);

    if (!isValidDisplayDate(fromDisplay)) {
      setError("Invalid start date. Use MM-DD-YYYY.");
      return;
    }
    if (!isValidDisplayDate(toDisplay)) {
      setError("Invalid end date. Use MM-DD-YYYY.");
      return;
    }

    const apiFrom = toApiDate(fromDisplay);
    const apiTo = toApiDate(toDisplay);

    if (apiFrom > apiTo) {
      setError("Start date must be before end date.");
      return;
    }

    setDateRange({ from: apiFrom, to: apiTo });
    setOpen(false);
  };

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-card px-6">
      <div className="flex items-center gap-6">
        <h1 className="text-lg font-semibold text-card-foreground">Dashboard</h1>
      </div>

      <div className="flex items-center gap-4">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Calendar className="h-4 w-4" />
              {fromDisplay && toDisplay
                ? `${fromDisplay} — ${toDisplay}`
                : "Select Date Range"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">
                  Start Date (MM-DD-YYYY)
                </label>
                <Input
                  type="text"
                  placeholder="01-01-2025"
                  value={fromDisplay}
                  onChange={(e) => setFromDisplay(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">
                  End Date (MM-DD-YYYY)
                </label>
                <Input
                  type="text"
                  placeholder="03-31-2025"
                  value={toDisplay}
                  onChange={(e) => setToDisplay(e.target.value)}
                  className="mt-1"
                />
              </div>
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
              <Button onClick={handleApply} className="w-full">
                Apply Filters
              </Button>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </header>
  );
}
