import { Card } from "@/components/ui/card";
import { useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";

interface AutomationKPI {
  label: string;
  percentage: number;
  value: number;
  totalValue: number;
}

const kpiLabels: Record<string, string> = {
  pa: "Prior Authorization",
  charge: "Charge Entry",
  pp: "Payment Posting",
  ev: "Eligibility Verification",
  ar: "Account Receivable",
  cs: "Claim Submission",
  dm: "Denial Management",
  cr: "Coding Review",
  era: "ERA Processing",
  rm: "Referral Management",
  id: "Insurance Discovery",
  ap: "Appeal Processing",
  cred: "Credentialing",
  bar: "Billing Accuracy Report",
  ft: "FastTrack Appointments",
  ef: "Encounters form",
  eaa: "SDEC Eligibility and Auth",
  hs: "WKI HubSpot",
  ics: "WKI Injection charge scrub",
  mcs: "WKI Medical Charge Scrub",
  np: "WKI Non Par",
  nsa: "WKI No Show Appointment",
  dc: "Drug Count",
  sef: "SDEC Encounters Form",
};

export function AutomationKpis() {
  const { kpis, kpisLoading } = useDashboard();

  const { automationKpis, overallPercentage } = useMemo(() => {
    if (!kpis?.automation) return { automationKpis: [], overallPercentage: 0 };

    const automationKpis: AutomationKPI[] = [];

    Object.entries(kpis.automation).forEach(([key, val]) => {
      if (val && typeof val === "object" && val.bot !== undefined && val.total !== undefined) {
        const pct = val.total > 0 ? (val.bot / val.total) * 100 : 0;
        automationKpis.push({
          label: kpiLabels[key] || key,
          percentage: Math.round(pct * 10) / 10,
          value: val.bot,
          totalValue: val.total,
        });
      }
    });

    const totalPct = automationKpis.reduce((s, k) => s + k.percentage, 0);
    const avgPct = automationKpis.length > 0 ? totalPct / automationKpis.length : 0;

    return { automationKpis, overallPercentage: Math.round(avgPct) };
  }, [kpis]);

  const getGaugeColor = (percentage: number) => {
    if (percentage < 50) return { gauge: "#ef4444", status: "Low Efficiency" };
    if (percentage < 80) return { gauge: "#f59e0b", status: "Medium Efficiency" };
    return { gauge: "#10b981", status: "High Efficiency" };
  };

  const gaugeStyle = getGaugeColor(overallPercentage);
  const gaugePercentage = Math.min(Math.max(overallPercentage, 0), 100);
  const needleAngle = 180 - (gaugePercentage / 100) * 180;
  const needleRadians = (needleAngle * Math.PI) / 180;
  const centerX = 120;
  const centerY = 100;
  const radius = 60;
  const needleX = centerX + radius * Math.cos(needleRadians);
  const needleY = centerY - radius * Math.sin(needleRadians);

  if (kpisLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <div className="p-6 h-96 bg-secondary rounded animate-pulse" />
      </Card>
    );
  }

  return (
    <Card className="flex flex-col h-full border border-gray-100 rounded-lg shadow">
      <div className="p-2 border-b border-border">
        <h3 className="text-center text-sm font-semibold text-card-foreground mb-6">
          Overall Automation Performance
        </h3>

        <div className="flex justify-center mb-4">
          <svg viewBox="0 0 240 140" className="w-full h-auto" style={{ maxWidth: "200px" }}>
            <path d="M 30 100 A 90 90 0 0 1 210 100" fill="none" stroke="#e5e7eb" strokeWidth="16" strokeLinecap="round" />
            <path d="M 30 100 A 90 90 0 0 1 90 20" fill="none" stroke="#ef4444" strokeWidth="16" strokeLinecap="round" />
            <path d="M 90 20 A 90 90 0 0 1 150 20" fill="none" stroke="#f59e0b" strokeWidth="16" strokeLinecap="round" />
            <path d="M 150 20 A 90 90 0 0 1 210 100" fill="none" stroke="#10b981" strokeWidth="16" strokeLinecap="round" />
            <line x1="120" y1="100" x2={needleX} y2={needleY} stroke={gaugeStyle.gauge} strokeWidth="3" strokeLinecap="round" />
            <circle cx="120" cy="100" r="5" fill={gaugeStyle.gauge} />
            <text x="30" y="125" fontSize="11" fill="#6b7280" textAnchor="middle" fontWeight="500">0%</text>
            <text x="120" y="125" fontSize="11" fill="#6b7280" textAnchor="middle" fontWeight="500">50%</text>
            <text x="210" y="125" fontSize="11" fill="#6b7280" textAnchor="middle" fontWeight="500">100%</text>
          </svg>
        </div>

        <div className="flex items-center justify-center gap-8 mt-2">
          <div className="text-center">
            <p className="text-2xl font-bold text-card-foreground">{overallPercentage}%</p>
            <p className="text-xs font-medium" style={{ color: gaugeStyle.gauge }}>{gaugeStyle.status}</p>
          </div>
          <div className="w-px h-12 bg-border" />
          <div className="text-center">
            <p className="text-lg font-semibold text-card-foreground">{automationKpis.length}</p>
            <p className="text-[12px] text-muted-foreground">Total KPIs</p>
          </div>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        <h3 className="text-xs font-semibold text-muted-foreground mb-3">Automation Penetration</h3>
        <div className="flex flex-col gap-4">
          {automationKpis.map((kpi, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <div className="flex-1 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-card-foreground line-clamp-1">{kpi.label}</label>
                  <span className="text-xs font-bold text-card-foreground ml-2 shrink-0">{Math.round(kpi.percentage)}%</span>
                </div>
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(kpi.percentage, 100)}%`,
                      backgroundColor: kpi.percentage >= 80 ? "#10b981" : kpi.percentage >= 50 ? "#f59e0b" : "#ef4444",
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {automationKpis.length === 0 && (
          <div className="flex items-center justify-center h-24 text-sm text-muted-foreground">
            No automation data available
          </div>
        )}
      </div>
    </Card>
  );
}
