import { cn } from "@/lib/utils";
import { useDashboard } from "@/lib/dashboard-context";
import {
  LayoutDashboard,
  Users,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from "lucide-react";
import { useState } from "react";

const bottomItems = [
  { icon: Settings, label: "Settings" },
  { icon: HelpCircle, label: "Help" },
];

export function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const {
    clients,
    clientsLoading,
    activeClientIds,
    setActiveClientIds,
  } = useDashboard();

  const isAllClients =
    clients.length > 0 && activeClientIds.length === clients.length;

  const handleSelectAll = () => {
    setActiveClientIds(clients.map((c) => c.id));
  };

  const handleSelectClient = (clientId: string) => {
    setActiveClientIds([clientId]);
  };

  return (
    <aside
      className={cn(
        "flex h-screen flex-col bg-sidebar text-sidebar-foreground transition-all duration-300",
        collapsed ? "w-16" : "w-56",
      )}
    >
      {/* Logo */}
      <div className="flex h-20 items-center justify-center px-4">
        <span
          className={cn(
            "font-bold text-sidebar-primary transition-all",
            collapsed ? "text-sm" : "text-xl",
          )}
        >
          {collapsed ? "RCM" : "RCM Analytics"}
        </span>
      </div>

      {/* Dashboards */}
      <nav className="flex flex-1 flex-col gap-1 px-2 pt-4">
        {/* All Clients option */}
        {clients.length > 1 && (
          <button
            onClick={handleSelectAll}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              isAllClients
                ? "bg-sidebar-accent text-sidebar-primary"
                : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground",
            )}
          >
            <LayoutDashboard className="h-4 w-4 shrink-0" />
            {!collapsed && <span>All Clients</span>}
          </button>
        )}

        {/* Individual clients — dynamically rendered */}
        {clientsLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-4 w-4 animate-spin text-sidebar-foreground/40" />
          </div>
        ) : (
          clients.map((client) => {
            const isActive =
              !isAllClients &&
              activeClientIds.length === 1 &&
              activeClientIds[0] === client.id;

            return (
              <button
                key={client.id}
                onClick={() => handleSelectClient(client.id)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-primary"
                    : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                )}
              >
                <Users className="h-4 w-4 shrink-0" />
                {!collapsed && <span>{client.name}</span>}
              </button>
            );
          })
        )}
      </nav>

      {/* Bottom items */}
      <div className="flex flex-col gap-1 border-t border-sidebar-border px-2 py-3">
        {bottomItems.map((item) => (
          <button
            key={item.label}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            <item.icon className="h-4 w-4 shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </button>
        ))}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/40 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4 shrink-0" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4 shrink-0" />
              <span>Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
}
