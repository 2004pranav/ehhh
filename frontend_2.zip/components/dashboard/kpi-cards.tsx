import { Card } from "@/components/ui/card";
import {
  DollarSign,
  FileText,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import type { NormalizedKpis } from "@/lib/types";

interface KpiCardConfig {
  label: string;
  key: keyof NormalizedKpis;
  icon: LucideIcon;
  color: string;
  bgColor: string;
  format: (val: number) => string;
}

const kpiConfig: KpiCardConfig[] = [
  {
    label: "Total Claims",
    key: "total_claims",
    icon: FileText,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%,60%)]/10",
    format: (val) => val.toLocaleString(),
  },
  {
    label: "Total Payments",
    key: "total_payments",
    icon: DollarSign,
    color: "text-[hsl(168,76%,42%)]",
    bgColor: "bg-[hsl(168,76%,42%)]/10",
    format: (val) => `$${(val / 1_000_000).toFixed(1)}M`,
  },
  {
    label: "Total Billed",
    key: "total_charges",
    icon: DollarSign,
    color: "text-[hsl(262,83%,58%)]",
    bgColor: "bg-[hsl(262,83%,58%)]/10",
    format: (val) => `$${(val / 1_000_000).toFixed(1)}M`,
  },
  {
    label: "GCR",
    key: "gcr",
    icon: TrendingUp,
    color: "text-[hsl(38,92%,50%)]",
    bgColor: "bg-[hsl(38,92%,50%)]/10",
    format: (val) => `${val.toFixed(1)}%`,
  },
  {
    label: "NCR",
    key: "ncr",
    icon: TrendingUp,
    color: "text-[hsl(38,92%,50%)]",
    bgColor: "bg-[hsl(38,92%,50%)]/10",
    format: (val) => `${val.toFixed(1)}%`,
  },
  {
    label: "Denial Rate",
    key: "denial_rate",
    icon: TrendingDown,
    color: "text-[hsl(0,84%,60%)]",
    bgColor: "bg-[hsl(0,84%,60%)]/10",
    format: (val) => `${val.toFixed(4)}%`,
  },
  {
    label: "CCR",
    key: "ccr",
    icon: ShieldCheck,
    color: "text-[hsl(168,76%,42%)]",
    bgColor: "bg-[hsl(168,76%,42%)]/10",
    format: (val) => `${val.toFixed(1)}%`,
  },
  {
    label: "AR Days",
    key: "ar_days",
    icon: Zap,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%,60%)]/10",
    format: (val) => `${val.toFixed(1)}`,
  },
];

export function KpiCards() {
  const { kpis, kpisLoading } = useDashboard();

  const computedKpis = useMemo(() => {
    if (!kpis) return kpiConfig.map((cfg) => ({ ...cfg, value: "—" }));
    return kpiConfig.map((cfg) => ({
      ...cfg,
      value: cfg.format(Number(kpis[cfg.key]) || 0),
    }));
  }, [kpis]);

  if (kpisLoading) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {Array.from({ length: kpiConfig.length }).map((_, i) => (
          <Card key={i} className="border-0 p-4 shadow-sm animate-pulse">
            <div className="h-10 w-10 rounded-lg bg-secondary mb-2" />
            <div className="h-4 bg-secondary rounded mb-1" />
            <div className="h-5 bg-secondary rounded w-3/4" />
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      {computedKpis.map((kpi) => (
        <Card key={kpi.label} className="flex items-center gap-4 border-0 p-4 shadow-sm">
          <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", kpi.bgColor)}>
            <kpi.icon className={cn("h-5 w-5", kpi.color)} />
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-medium text-muted-foreground">{kpi.label}</span>
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-card-foreground">{kpi.value}</span>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
