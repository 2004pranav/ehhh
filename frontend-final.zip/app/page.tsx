'use client'

import { DashboardProvider, useDashboard } from '@/lib/dashboard-context'
import { DashboardSidebar } from '@/components/dashboard/sidebar'
import { DashboardHeader } from '@/components/dashboard/header'
import { KpiCards } from '@/components/dashboard/kpi-cards'
import { AutomationKpis } from '@/components/dashboard/automation-kpis'
import {
  PerformanceTrendsChart,
  RevenueChart,
  ArAgingChart,
  ARDaysTrendChart,
  PeriodComparisonChart,
} from '@/components/dashboard/charts'
import { AlertCircle, RefreshCw } from 'lucide-react'

function ErrorBanner() {
  const { kpisError, retryKpis } = useDashboard()

  if (!kpisError) return null

  return (
    <div className="mx-4 mt-4 flex items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3">
      <AlertCircle className="h-4 w-4 shrink-0 text-destructive" />
      <p className="flex-1 text-sm text-destructive">{kpisError}</p>
      <button
        onClick={retryKpis}
        className="flex items-center gap-1.5 rounded-md bg-destructive/10 px-3 py-1.5 text-xs font-medium text-destructive transition-colors hover:bg-destructive/20"
      >
        <RefreshCw className="h-3 w-3" />
        Retry
      </button>
    </div>
  )
}

function DashboardContent() {
  const { kpisLoading } = useDashboard()

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        <ErrorBanner />

        {/* Main content — scrollable to prevent overlap at any zoom */}
        <main
          className={`flex-1 overflow-y-auto p-4 transition-opacity duration-300 ease-in-out ${
            kpisLoading ? 'opacity-60' : 'opacity-100'
          }`}
        >
          <div className="flex gap-4 min-h-0">

            {/* LEFT ~70% — KPI cards + chart rows */}
            <div className="flex-[7] flex flex-col gap-4">

              {/* KPI Cards */}
              <div className="shrink-0">
                <KpiCards />
              </div>

              {/* Row 1: AR Aging | AR Days Trend | Period Comparison */}
              <div className="grid grid-cols-3 gap-4">
                <ArAgingChart />
                <ARDaysTrendChart />
                <PeriodComparisonChart />
              </div>

              {/* Row 2: Performance Trends | Revenue Overview */}
              <div className="grid grid-cols-2 gap-4">
                <PerformanceTrendsChart />
                <RevenueChart />
              </div>

            </div>

            {/* RIGHT ~30% — Automation panel */}
            <div className="flex-[3] min-h-0">
              <AutomationKpis />
            </div>

          </div>
        </main>
      </div>
    </div>
  )
}

export default function Page() {
  return (
    <DashboardProvider>
      <DashboardContent />
    </DashboardProvider>
  )
}
