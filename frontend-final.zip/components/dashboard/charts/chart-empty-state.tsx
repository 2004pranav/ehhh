import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3 } from "lucide-react";

interface ChartEmptyStateProps {
  title: string;
  message?: string;
}

export function ChartEmptyState({
  title,
  message = "No data for this period — try adjusting the date range.",
}: ChartEmptyStateProps) {
  return (
    <Card className="border-0 shadow-sm h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-col items-center justify-center gap-3 py-10">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <BarChart3 className="h-6 w-6 text-muted-foreground/60" />
          </div>
          <p className="text-sm text-muted-foreground text-center max-w-[200px] leading-relaxed">
            {message}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

export function ChartSkeleton({ title }: { title: string }) {
  return (
    <Card className="border-0 shadow-sm h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-48 bg-secondary rounded animate-pulse" />
      </CardContent>
    </Card>
  );
}
