import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  PieChart, Pie, Cell,
  Tooltip, ResponsiveContainer,
} from "recharts";
import { useMemo } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import { PIE_COLORS, formatAmount } from "./chart-constants";
import { ChartSkeleton, ChartEmptyState } from "./chart-empty-state";

interface AgingSlice {
  period: string;
  value: number;
  amount: string;
}

export function ArAgingChart() {
  const { kpis, kpisLoading } = useDashboard();

  const arData = useMemo<AgingSlice[]>(() => {
    if (!kpis?.ar_aging?.buckets) return [];
    try {
      return kpis.ar_aging.buckets.map((b) => ({
        period: b.period,
        value: b.percentage,
        amount: formatAmount(b.amount),
      }));
    } catch (error) {
      console.error("Error processing AR data:", error);
      return [];
    }
  }, [kpis]);

  if (kpisLoading) return <ChartSkeleton title="AR Aging Buckets" />;
  if (!arData.length) return <ChartEmptyState title="AR Aging Buckets" />;

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">AR Aging Buckets</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center gap-2">
          <div className="h-40 w-40 shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={arData} cx="50%" cy="50%" innerRadius={40} outerRadius={62} paddingAngle={3} dataKey="value" stroke="none" startAngle={90} endAngle={-270}>
                  {arData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ borderRadius: "8px", border: "1px solid hsl(220, 13%, 91%)", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)", fontSize: "12px" }}
                  formatter={(val: number, _name: string, props: { payload: AgingSlice }) => [`${props.payload.amount} (${val}%)`]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-col gap-3">
            {arData.map((entry, idx) => (
              <div key={entry.period} className="flex items-center gap-2.5">
                <span className="inline-block h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }} />
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-card-foreground">{entry.period}</span>
                  <span className="text-xs text-muted-foreground">{entry.amount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
