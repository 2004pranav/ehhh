import { useState } from "react";
import { format } from "date-fns";
import { useDashboard } from "@/lib/dashboard-context";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon } from "lucide-react";
import type { DateRange as RDPDateRange } from "react-day-picker";

export function DashboardHeader() {
  const { dateRange, setDateRange } = useDashboard();
  const [open, setOpen] = useState(false);

  // Convert API strings to Date objects for the calendar
  const selected: RDPDateRange = {
    from: new Date(dateRange.from + "T00:00:00"),
    to: new Date(dateRange.to + "T00:00:00"),
  };

  const handleSelect = (range: RDPDateRange | undefined) => {
    if (range?.from && range?.to) {
      setDateRange({
        from: format(range.from, "yyyy-MM-dd"),
        to: format(range.to, "yyyy-MM-dd"),
      });
      setOpen(false);
    }
  };

  const displayFrom = selected.from ? format(selected.from, "MMM dd, yyyy") : "";
  const displayTo = selected.to ? format(selected.to, "MMM dd, yyyy") : "";

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-card px-6">
      <div className="flex items-center gap-6">
        <h1 className="text-lg font-semibold text-card-foreground">Dashboard</h1>
      </div>

      <div className="flex items-center gap-4">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2 font-normal">
              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
              {displayFrom && displayTo
                ? `${displayFrom} — ${displayTo}`
                : "Select Date Range"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <Calendar
              mode="range"
              selected={selected}
              onSelect={handleSelect}
              numberOfMonths={2}
              defaultMonth={selected.from}
            />
          </PopoverContent>
        </Popover>
      </div>
    </header>
  );
}
