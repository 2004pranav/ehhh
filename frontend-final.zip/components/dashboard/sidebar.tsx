import { cn } from "@/lib/utils";
import { useDashboard } from "@/lib/dashboard-context";
import {
  LayoutDashboard,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Loader2,
  CalendarDays,
} from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

const AVATAR_COLORS = [
  "bg-blue-500",
  "bg-emerald-500",
  "bg-purple-500",
  "bg-amber-500",
  "bg-rose-500",
  "bg-cyan-500",
  "bg-indigo-500",
  "bg-teal-500",
];

function getInitials(name: string): string {
  return name
    .split(/\s+/)
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

const bottomItems = [
  { icon: Settings, label: "Settings" },
  { icon: HelpCircle, label: "Help" },
];

export function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const {
    clients,
    clientsLoading,
    activeClientIds,
    setActiveClientIds,
    dateRange,
  } = useDashboard();

  const isAllClients =
    clients.length > 0 && activeClientIds.length === clients.length;

  const handleSelectAll = () => {
    setActiveClientIds(clients.map((c) => c.id));
  };

  const handleSelectClient = (clientId: string) => {
    setActiveClientIds([clientId]);
  };

  const fromDisplay = (() => {
    try { return format(new Date(dateRange.from + "T00:00:00"), "MMM dd, yyyy"); }
    catch { return dateRange.from; }
  })();
  const toDisplay = (() => {
    try { return format(new Date(dateRange.to + "T00:00:00"), "MMM dd, yyyy"); }
    catch { return dateRange.to; }
  })();

  return (
    <aside
      className={cn(
        "flex h-screen flex-col bg-sidebar text-sidebar-foreground transition-all duration-300",
        collapsed ? "w-16" : "w-56",
      )}
    >
      {/* Logo */}
      <div className="flex h-20 items-center justify-center px-4">
        <span
          className={cn(
            "font-bold text-sidebar-primary transition-all",
            collapsed ? "text-sm" : "text-xl",
          )}
        >
          {collapsed ? "RCM" : "RCM Analytics"}
        </span>
      </div>

      {/* Dashboards */}
      <nav className="flex flex-1 flex-col gap-1 px-2 pt-4">
        {/* All Clients option */}
        {clients.length > 1 && (
          <button
            onClick={handleSelectAll}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all relative",
              isAllClients
                ? "bg-sidebar-accent text-sidebar-primary border-l-[3px] border-sidebar-primary"
                : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground border-l-[3px] border-transparent",
            )}
          >
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-purple-500">
              <LayoutDashboard className="h-3.5 w-3.5 text-white" />
            </div>
            {!collapsed && <span>All Clients</span>}
          </button>
        )}

        {/* Individual clients */}
        {clientsLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-4 w-4 animate-spin text-sidebar-foreground/40" />
          </div>
        ) : (
          clients.map((client, idx) => {
            const isActive =
              !isAllClients &&
              activeClientIds.length === 1 &&
              activeClientIds[0] === client.id;

            const initials = getInitials(client.name);
            const colorClass = AVATAR_COLORS[idx % AVATAR_COLORS.length];

            return (
              <button
                key={client.id}
                onClick={() => handleSelectClient(client.id)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all relative",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-primary border-l-[3px] border-sidebar-primary"
                    : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground border-l-[3px] border-transparent",
                )}
              >
                <div
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-bold text-white",
                    colorClass,
                  )}
                >
                  {initials}
                </div>
                {!collapsed && <span>{client.name}</span>}
              </button>
            );
          })
        )}
      </nav>

      {/* Date range indicator */}
      {!collapsed && (
        <div className="mx-3 mb-3 rounded-lg bg-sidebar-accent/60 px-3 py-2.5">
          <div className="flex items-center gap-2 text-[11px] font-medium text-sidebar-foreground/50 mb-1">
            <CalendarDays className="h-3 w-3" />
            Period
          </div>
          <p className="text-xs font-semibold text-sidebar-foreground/80 leading-relaxed">
            {fromDisplay}
          </p>
          <p className="text-xs font-semibold text-sidebar-foreground/80 leading-relaxed">
            to {toDisplay}
          </p>
        </div>
      )}

      {/* Bottom items */}
      <div className="flex flex-col gap-1 border-t border-sidebar-border px-2 py-3">
        {bottomItems.map((item) => (
          <button
            key={item.label}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            <item.icon className="h-4 w-4 shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </button>
        ))}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/40 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4 shrink-0" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4 shrink-0" />
              <span>Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
}
